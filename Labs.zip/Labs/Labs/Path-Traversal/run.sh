run() {
  echo "Running $1"
  cd $1
  bash run.sh
  cd ..
}

run 1_path_traversal_read
run 2_path_traversal_read_abs
run 3_path_traversal_write
run 4_zip_slip