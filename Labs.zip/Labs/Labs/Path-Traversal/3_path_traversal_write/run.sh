#!/bin/bash

# change these
DOCKERNAME=path_traversal_write
DOCKERFILE_NAME=Dockerfile
docker stop $DOCKERNAME
docker rm $DOCKERNAME
docker rmi $DOCKERNAME
docker build -t $DOCKERNAME --file $DOCKERFILE_NAME .

#docker run -d -p 0.0.0.0:8092:80 -v "$(pwd)"/html:/var/www/html --name $DOCKERNAME $DOCKERNAME
docker run -d -p 127.0.0.1:8092:80 --name $DOCKERNAME $DOCKERNAME
