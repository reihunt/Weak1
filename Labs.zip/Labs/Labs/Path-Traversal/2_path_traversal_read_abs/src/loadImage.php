<?php 

$file = $_GET['file'];

if (file_exists($file)) {

    header('Content-Type: image/png');

    header('Content-Length: ' . filesize($file));

   readfile($file);
}
else { // Image file not found

    echo " 404 Not Found";

}?>