#!/bin/bash
# change these
DOCKERNAME=path_traversal_read_abs
DOCKERFILE_NAME=Dockerfile
docker stop $DOCKERNAME
docker rm $DOCKERNAME
#docker rmi $DOCKERNAME
docker build -t $DOCKERNAME --file $DOCKERFILE_NAME .
# Below line is for apps that has 1 Dockerfile only
# Remember to change expose port too
docker run -d -p 127.0.0.1:8091:80 --name $DOCKERNAME $DOCKERNAME
