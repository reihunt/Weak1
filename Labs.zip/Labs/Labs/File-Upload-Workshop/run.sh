#!/bin/bash

build() {
  echo "Building $1"
  cd $1
  bash build.sh
  cd ..
}

build level1
build level2
build level3
build level4
build level5
build level6
build level7
build level8

sudo docker-compose down -v
sudo docker-compose up --build -d
