#!/bin/bash

# change these
DOCKERNAME=upload-file-playground-level-8
DOCKERFILE_NAME=Dockerfile

# Dont change this :(
TAGNAME=cyberjutsu/training-labs:$DOCKERNAME

sudo docker stop $DOCKERNAME
sudo docker rm $DOCKERNAME
sudo docker build --no-cache -t $TAGNAME --file $DOCKERFILE_NAME .
