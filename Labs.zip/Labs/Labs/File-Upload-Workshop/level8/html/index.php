<?php
    error_reporting(0);
    if (!isset($_GET['game'])) {
        header('Location: /?game=fatty-bird-1.html');
    }
    $game = $_GET['game'];
    if(isset($_GET["debug"])) die(highlight_file(__FILE__));
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include './views/header.html'; ?>
    </head>

    <body>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a href="?game=fatty-bird-1.html&debug">Debug source</a>
        </nav>
        <br><br>
        <h3 class="display-4 text-center">File upload workshop</h3>
        <h4 class="display-4 text-center">Level 8</h4>
        <p class="display-5 text-center">Goal: read /etc/passwd</p>

        <br>
        <div style="background-color: white; padding: 20px;">
            <?php include './views/' . $game; ?>
        </div>

    </body>

    <?php include './views/footer.html' ?>
</html>
