<?php
    error_reporting(0);

    // Create store place for each user (we place this in /usr/upload for easily handle)
    session_start();
    if (!isset($_SESSION['dir'])) {
        $_SESSION['dir'] = '/usr/upload/' . session_id();
    }
    $dir = $_SESSION['dir'];
    if ( !file_exists($dir) )
        mkdir($dir);

    $cmd = '';
    $error = '';
    $success = '';
    $debug = '...';
    if(isset($_GET["debug"])) die(highlight_file(__FILE__));
    if(isset($_FILES["file"])) {
        try {
            // Save file to user's directory
            $newFile = $dir . "/" . $_FILES["file"]["name"];
            move_uploaded_file($_FILES["file"]["tmp_name"], $newFile);

            // unzip the file
            $cmd = "unzip " . $newFile . " -d " . $dir;
            $debug = shell_exec($cmd);

            // Remove /usr/ from directory
            $user_dir = substr($dir, 5);
            $success = 'Successfully uploaded and unzip files into ' . $user_dir . '/' . $_FILES["file"]["name"];
        } catch(Exception $e) {
            $error = $e->getMessage();
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <title>PHP upload Level 7</title>

        <!-- This is for UI only -->
        <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css" integrity="sha512-P5MgMn1jBN01asBgU0z60Qk4QxiXo86+wlFahKrsQf37c9cro517WzVSPPV1tDKzhku2iJ2FVgL67wG03SGnNA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    </head>
    <body>
        <br/>
        <br/>
        <h3 class="display-4 text-center">File upload workshop</h3>
        <h4 class="display-4 text-center">Level 7</h4>
        <p class="display-5 text-center">File handling bug: Unzipper</p>
        <p class="display-5 text-center font-italic">CHANGELOG: From this challenge onwards, we have configured apache securely, you can read the config if you like:
            <br>
            <a href="/apache2.conf">apache2.conf</a><br>
            <a href="/000-default.conf">000-default.conf</a>
        </p>
        <p class="display-5 text-center">Goal: RCE me!</p>

        <br/>
        <div class="container">
            <a href="/?debug">Debug source</a><br/>

            <form method="post" enctype="multipart/form-data">
                Select zip file to upload and extract: <br>
                <input type="file" name="file" id="file">
                <br><br>
                <input type="submit">
            </form>
            <br>
            <p style="color:blue"><?php echo 'Unzipper command: ' . $cmd; ?></p>
            <p style="color:red"><?php echo $error; ?></p>
            <p style="color:green"><?php echo $success; ?></p>

            <br><br>
            <p class="display-5 font-italic">Unzipper debug info:</p>
            <pre>
                <?php echo $debug; ?>
            </pre>
        </div>

    </body>

    <footer class="container">
        <br/>
        <br/>
        <br/>
        <button class="float-left btn btn-dark" type="button" onclick="prevLevel()">Previous level</button>
        <button class="float-right btn btn-dark" type="button" onclick="nextLevel()">Next level</button>

        <script>
          function prevLevel() {
            const url = new URL(origin);
            url.port = (parseInt(url.port) - 1).toString();
            location.href = url.toString();
          }
          function nextLevel() {
            const url = new URL(origin);
            url.port = (parseInt(url.port) + 1).toString();
            location.href = url.toString();
          }
        </script>

    </footer>
</html>
